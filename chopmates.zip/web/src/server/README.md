# server
Server endpoints or actions live here (OTP, posts, matches, payments, notify, sms webhook).
