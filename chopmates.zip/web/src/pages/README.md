# pages
Site pages: /, /signup, /dashboard, /partners, /ambassadors, /events, /benefactor.
