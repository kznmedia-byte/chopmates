# Benefactor
Notes on enabling the Benefactor flow after MVP launch.
