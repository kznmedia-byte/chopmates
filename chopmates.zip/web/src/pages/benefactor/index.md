# Benefactor — Coming Soon

Join as a **Benefactor** to bless people regularly. Choose to be public or anonymous.
- One-tap **Offer** flow
- Sponsor drives
- Appear on the Benefactor Wall (optional)

> This page is a placeholder. Enable the feature when traffic grows.
