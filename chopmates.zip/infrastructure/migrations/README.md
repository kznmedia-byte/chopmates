# Migrations
Use SQL editor in Supabase to apply `supabase-schema.sql`.
