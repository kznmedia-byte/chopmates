# Brand Guide

## Colors
| Name | Hex | Usage |
|------|-----|-------|
| Orange | #E76F51 | Primary CTAs, accents, heart 🧡 |
| Green  | #386641 | Success, links, highlights |
| Brown  | #8D5524 | Headlines, body text on light bg |
| Cream  | #FAF3E0 | Background bands, soft sections |

## Fonts
- Poppins (preferred) or Nunito
- Rounded corners, soft shadows, large buttons

## Voice
Warm, Nigerian, dignifying. Light Pidgin where helpful.
